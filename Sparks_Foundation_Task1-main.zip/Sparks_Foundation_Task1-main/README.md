# Sparks_Foundation_Task1
Prediction using linear regression

Language: Python IDE: Jupyter Notebook 

Dataset Link: http://bit.ly/w-data

The Sparks Foundation https://lnkd.in/dZCEuyV9
